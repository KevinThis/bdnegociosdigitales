/* ============================ STORED PROCEDURES ============================ */

CREATE DATABASE bdstored;
GO

USE bdstored;
GO

-- Ejemplo Simple

CREATE PROCEDURE usp_Mensaje_Saludar
    -- No tendrá parámetros
AS
BEGIN
    PRINT 'Hola Mundo Transact SQL desde SQL SERVER';
END;
GO

-- Ejecutar
EXECUTE usp_Mensaje_Saludar;
GO

CREATE PROC usp_Mensaje_Saludar2
    -- No tendrá parámetros
AS
BEGIN
    PRINT 'Hola Mundo Ing en TI';
END;
GO

-- Ejecutar
EXEC usp_Mensaje_Saludar2;
GO

CREATE OR ALTER PROC usp_Mensaje_Saludar3
    -- No tendrá parámetros -- Para cambiar el nombre o datos
AS
BEGIN
    PRINT 'Hola Mundo Entornos Virtuales y Negocios Digitales';
END;
GO

-- Eliminar un SP
DROP PROCEDURE usp_Mensaje_Saludar3;
GO

-- Ejecutar
EXEC usp_Mensaje_Saludar3;
GO

-- Crear un SP que muestre la fecha actual del sistema
CREATE OR ALTER PROC usp_Servidor_FechaActual

AS
BEGIN
    SELECT CAST(GETDATE () AS DATE) AS [ FECHA DEL SISTEMA ]
END;
GO

-- Ejecutar
EXEC usp_Servidor_FechaActual;

-- Crear un SP que muestre el nombre de la base de datos (DB_NAME())
CREATE OR ALTER PROC spu_Dbname_get
AS
BEGIN
    SELECT
    HOST_NAME() AS [MACHINE],
    SUSER_NAME() AS [SQLUSER],
    SYSTEM_USER AS [SYSTEMUSER],
    DB_NAME() AS [DATABASE NAME],
    APP_NAME() AS [APPLICATION];
END;
GO

-- Ejecutar
EXEC spu_Dbname_get;
GO

/*=============================== STORED PROCEDURES CON PARÁMETROS===========================*/
CREATE OR ALTER PROC usp_persona_saludar
    @nombre VARCHAR(50) -- Parámetro de entrada
AS
BEGIN
    PRINT 'Hola ' + @nombre;
END;
GO

EXEC usp_persona_saludar 'Israel';
EXEC usp_persona_saludar 'Artemio';
EXEC usp_persona_saludar @Nombre = 'Bryan';

DECLARE @name VARCHAR(50);
SET @name = 'Yael';

EXEC usp_persona_saludar @name

/* Todo: Ejemplo con consultas, vamos a crear una tabla de clientes basada en la tabla de Customers de Northwind */
SELECT CustomerID, CompanyName
INTO Customers
FROM NORTHWND.dbo.Customers;
GO

-- Crear un SP que busque un cliente en específico
CREATE OR ALTER PROC spu_Customer_buscar
@id NCHAR(10)
AS
BEGIN

    SET @id = TRIM(@id);
    PRINT (@id)
    PRINT LEN(@id)

    IF LEN(@id) <= 0 OR LEN(@id) > 5
    BEGIN
        PRINT('El ID debe estar en el rango de 1 a 5 de tamaño');
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Customers WHERE CustomerID = @id)
    BEGIN
        SELECT CustomerID AS [Número], CompanyName AS [Cliente]
        FROM Customers
        WHERE CustomerID = @id;
    END
    ELSE
        PRINT 'El cliente no existe en la BD'
END;
GO

SELECT *
FROM Customers
WHERE CustomerID = '';

-- Ejecutar
EXEC spu_Customer_buscar 'YUTTT ';

SELECT 1
FROM NORTHWND.dbo.Categories
WHERE NOT EXISTS(
SELECT 1
FROM Customers
WHERE CustomerID = 'ANTONi');

-- Ejercicios: Crear un SP que reciba un número y que verifique que no sea negativo, si es negativo imprimir
-- valor no válido, y si no multiplicarlo por cinco y mostrarlo para mostrar usar un select

--

-- TODO: 